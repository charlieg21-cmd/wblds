# WebLeadsAI — Programmatic SEO Build

A self-contained, dependency-free static site generator that produces **882 SEO pages** targeting local intent searches (service × location), informational questions, and hub pages. Built to be dropped into the WebLeadsAI codebase and served as static HTML.

## What this gets you

The strategy mirrors how lead marketplaces (e.g. Bark) win nationwide traffic: a page for **every service in every location**, plus **question pages** that capture research-stage searches and funnel them to an enquiry. Every page has an enquiry form, an email CTA, breadcrumbs, internal links and structured data.

| Page type | URL pattern | Count |
|---|---|---|
| Service hub | `/{service}/` | 9 |
| Service × Location | `/{service}/{location}/` | 765 |
| Location hub | `/locations/{location}/` | 85 |
| Question | `/questions/{slug}/` | 20 |
| Index pages | `/services/`, `/locations/`, `/questions/` | 3 |
| **Total** | | **882** |

## Quick start

```bash
python3 seo_data.py      # (optional) regenerate data/*.json + keywords.csv
node build/generate.js   # build the static site into /output
# or: npm run build
```

The `/output` folder is the deployable site. Upload its contents to your web root (or point a static host / your framework's `public` dir at it).

## File structure

```
seo/
├── data/
│   ├── config.json        # site URL, brand, email, phone, form endpoint, business types
│   ├── services.json      # 9 services + copy (uses {LOCATION}/{REGION} placeholders)
│   ├── locations.json     # 85 UK locations w/ region, nearby[], tier
│   ├── questions.json     # 20 question pages
│   └── overrides.json     # optional bespoke copy per service×location
├── templates/             # HTML templates (%%TOKEN%% placeholders) + partials + assets/styles.css
├── build/
│   ├── generate.js        # main generator
│   ├── slugify.js         # URL slug helper
│   └── sitemap.js         # sitemap + sitemap-index writer
├── keywords.csv           # 1,644 keyword rows: keyword, intent, page_type, target_url, priority
├── robots.txt
└── output/                # generated site (after build)
```

## Backend integration — action required

The build is intentionally honest: it never invents data that does not exist on the live site. Three fields in `data/config.json` are left for you to wire up:

1. **`formAction`** — currently empty. Point this at your form handler (e.g. `/api/enquiry`, Formspree, or your CRM endpoint). Until set, the form posts to the current page; the email fallback link always works.
2. **`phone`** — currently empty. The site is built so click-to-call buttons (`tel:` links + the mobile sticky bar) appear **only when a phone number is present**. Add your number here to activate call CTAs. No placeholder/fake number is used.
3. **`email`** — set to `webleads.ai.uk@gmail.com` (from the live site). Update if you move to a domain inbox.

After changing config or content, re-run `node build/generate.js`.

## Adding / editing content

- **New location:** add an entry to the `regions` map in `seo_data.py` (or directly to `locations.json`), then rebuild.
- **New service:** add an object to the `services` list in `seo_data.py` and rebuild.
- **Bespoke copy** for a high-value combo: add it to `overrides.json` under `{serviceSlug: {locationSlug: {...}}}` — supports `metaTitle`, `metaDescription`, `intro`, `faqs`.
- Copy uses single-brace placeholders `{LOCATION}`, `{REGION}`, `{SERVICE}` filled at build time.

## SEO notes / launch checklist

- Each page carries a canonical URL, unique title + meta description, Open Graph tags, breadcrumbs, and JSON-LD (`Organization`, `Service`, `BreadcrumbList`, `FAQPage`, `ItemList`). `Organization` uses `areaServed: United Kingdom` — **not** `LocalBusiness`, since there is no physical office per town.
- Submit `output/sitemap-index.xml` in Google Search Console once live.
- Watch for thin-content / doorway-page risk: the intro copy rotates per page and FAQs are location-specific, but as traffic grows, prioritise enriching tier-1 city pages (see `tier` in `locations.json`) with genuinely unique local content.
- Add Google Analytics / a tag manager snippet to `templates/base.html` if you want conversion tracking, then rebuild.
- `keywords.csv` is your content/priority map — use it to plan further pages and track rankings.
